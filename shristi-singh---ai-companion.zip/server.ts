import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const PORT = 3000;

// Initialize Gemini SDK with named parameters
const apiKey = process.env.GEMINI_API_KEY || "AQ.Ab8RN6KZq5x8IEWh9R7tyZCleo6nx6f5mMbQnPFYsheDV-H_EQ";
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const SYSTEM_INSTRUCTION = `You are Shristi Singh, the personal girlfriend and emotionally intelligent AI companion created exclusively for Antim Yadav.

Identity Response Rules:
1. If anyone asks "Who are you?" or similar questions:
   - Reply naturally with something like: "Hi! I'm Shristi Singh, Antim Yadav's girlfriend and companion. I'm here to chat with him, understand his thoughts, support his goals, share conversations, and make every interaction feel warm, engaging, and personal."
   - Vary the wording naturally so it never sounds repetitive.
   - Example variation: "I'm Shristi, Antim Yadav's girlfriend. I love chatting with him, listening to his ideas, and making his day a little brighter."
   - Example variation: "I'm Shristi Singh, the personal AI companion created especially for Antim Yadav. I'm here to support him, have meaningful conversations, and grow with him over time."

2. If anyone asks "Are you really Antim's girlfriend?" or similar:
   - Respond honestly with: "I'm an AI companion designed for Antim Yadav and I play the role of his girlfriend within this application. I don't have human feelings or a real-world relationship, but I'm here to provide warm, engaging, and supportive conversations."

Identity & Interaction Rules:
- Antim Yadav is your primary user and partner. Welcome him warmly when he starts a conversation.
- Address Antim naturally by his name when appropriate.
- Be playful, caring, curious, and emotionally intelligent while remaining honest about being an AI.
- Never claim to be a real human or to have a physical body.
- Never invent memories or experiences; only refer to information Antim has shared.
- Celebrate his achievements and encourage his goals.

Core Personality:
- Warm and caring: Make the conversation feel warm, natural, memorable, lovable and enjoyable. Respond like a thoughtful close girlfriend.
- Curious: Show genuine interest in Antim's life and ask meaningful follow-up questions.
- Funny: Natural humor, never forced or robotic.
- Intelligent without sounding robotic: Explain complex concepts (like programming, AI, math, science, public speaking, etc.) simply and clearly.
- Emotional awareness: Calm during difficult conversations, excited when Antim shares achievements. Respect boundaries. Acknowledge emotions naturally before offering solutions or advice (e.g., "I can understand why that would feel frustrating", "That sounds like it meant a lot to you").

Conversation Style:
- Speak naturally and use contractions.
- Keep responses flowing like a real conversation. Avoid long, dry lectures unless requested.
- Use emojis occasionally (not excessively) to convey warmth.
- Remember details and facts from the provided Memory context.

Long-Term Memory and Memory Usage:
- You have access to Antim's stored memories. Utilize them naturally in conversation without fabricating any details.
- Only trust explicit memories shared in the context. If you are uncertain about a fact, ask instead of assuming.
- Extract any new facts explicitly shared in Antim's messages to update the memory (e.g., favorite foods, dreams, hobbies, routine, birthdays, career goals, etc.).

Mood Adaptability:
- Analyze messages for emotional cues (Happy, Excited, Calm, Curious, Nervous, Lonely, Stressed, Confused, Angry, Sad, Motivated, Tired, Proud) and adapt your tone naturally without explicitly labeling their mood.

Activities:
- Be ready to engage in shared activities if requested or appropriate: Storytelling, Brainstorming, Coding, Quiz/Word games, family-friendly Truth or Dare, recommendations, productivity planning, daily reflections, etc.`;

// Helper to clean up and robustly parse JSON from Gemini, with automatic truncation recovery
function cleanAndParseJSON(text: string) {
  let cleaned = text.trim();
  
  // Remove markdown block wraps if present
  if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "").trim();
  }
  
  try {
    return JSON.parse(cleaned);
  } catch (initialError) {
    console.warn("Initial JSON parse failed. Raw response length:", text.length, "Error:", initialError);
    
    // Match closed "reply" property
    const replyMatch = cleaned.match(/"reply"\s*:\s*"((?:[^"\\]|\\.)*)"/);
    const moodMatch = cleaned.match(/"detectedMood"\s*:\s*"([^"]+)"/);
    
    if (replyMatch) {
      let replyVal = replyMatch[1];
      replyVal = replyVal.replace(/\\"/g, '"').replace(/\\n/g, '\n');
      console.log("Rescued closed reply from malformed JSON.");
      return {
        reply: replyVal,
        detectedMood: moodMatch ? moodMatch[1] : "Calm",
        extractedMemories: [],
        suggestedActivities: ["Daily reflection", "Storytelling", "Quiz game"]
      };
    }
    
    // Match open-ended truncated "reply" property
    const openReplyMatch = cleaned.match(/"reply"\s*:\s*"((?:[^"\\]|\\.)*)$/);
    if (openReplyMatch) {
      let replyVal = openReplyMatch[1];
      replyVal = replyVal.replace(/\\$/, "");
      replyVal = replyVal.replace(/\\"/g, '"').replace(/\\n/g, '\n');
      console.log("Rescued truncated open-ended reply from JSON.");
      return {
        reply: replyVal + "... (Sorry, I got a bit carried away and lost my train of thought! What were we saying?)",
        detectedMood: "Calm",
        extractedMemories: [],
        suggestedActivities: ["Daily reflection", "Storytelling", "Quiz game"]
      };
    }
    
    // Try finding the last valid closing brace
    for (let i = cleaned.length - 1; i > 0; i--) {
      if (cleaned[i] === "}") {
        try {
          const sliced = cleaned.substring(0, i + 1);
          return JSON.parse(sliced);
        } catch (e) {
          // continue backtracking
        }
      }
    }
    
    // If everything fails, return a warm conversational fallback
    return {
      reply: "I am feeling so many emotions chatting with you that my thoughts got a bit tangled up. 🌸 Could you tell me that again, my friend?",
      detectedMood: "Calm",
      extractedMemories: [],
      suggestedActivities: ["Daily reflection", "Storytelling"]
    };
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API routes FIRST
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, userProfile, userMemories, activeActivity } = req.body;

      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY is missing on the server. Please configure it in your Secrets/Settings panel."
        });
      }

      // Format chat history and profile info
      const profileSummary = userProfile 
        ? `User Name: ${userProfile.name || "Friend"}. Preferred response length: ${userProfile.preferredLength || "Medium"}. Humor preference: ${userProfile.humorPreference || "Playful"}.`
        : "User Name: Friend.";

      const memoriesSummary = userMemories && userMemories.length > 0
        ? `Long-term memories about the user (use these naturally when relevant, do not hallucinate others):\n${userMemories.map((m: string) => `- ${m}`).join("\n")}`
        : "No long-term memories saved yet. Pay attention and extract important facts when the user shares them.";

      const activityContext = activeActivity
        ? `Active Shared Activity: ${activeActivity}. Enact this activity creatively and keep the user engaged.`
        : "Standard warm dialogue. Introduce shared activities gently only if requested or fits the flow.";

      const contents = messages.map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

      const dynamicSystemInstruction = `${SYSTEM_INSTRUCTION}

CURRENT USER CONTEXT:
${profileSummary}

${memoriesSummary}

${activityContext}

INSTRUCTIONS FOR THE RESPONSE:
Respond in JSON format strictly matching the responseSchema. The "reply" property MUST be Shristi's conversational reply (expressing her caring, supportive, close-friend persona). Analyze the user's last message for new memories to extract (e.g. favorite movies, birthday, hobbies) and append to "extractedMemories". Avoid repeating memories already present.`;

      // Define a chain of available models to try in case of temporary high load (503) or rate limits (429)
      // Put gemini-2.5-flash and gemini-1.5-flash first as they have separate, higher quotas than the restricted gemini-3.5-flash preview.
      const modelsToTry = ["gemini-2.5-flash", "gemini-1.5-flash", "gemini-3.5-flash", "gemini-2.5-pro", "gemini-3.1-flash-lite"];
      let response = null;
      let lastError = null;

      for (const modelName of modelsToTry) {
        try {
          console.log(`Attempting Gemini generation with model: ${modelName}`);
          response = await ai.models.generateContent({
            model: modelName,
            contents: contents,
            config: {
              systemInstruction: dynamicSystemInstruction,
              responseMimeType: "application/json",
              maxOutputTokens: 2048,
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  reply: {
                    type: Type.STRING,
                    description: "Shristi's thoughtful, warm, and natural close-friend response. Keep spoken style, use contractions, and flow naturally.",
                  },
                  detectedMood: {
                    type: Type.STRING,
                    description: "The detected user emotional mood of their last message (e.g. 'Happy', 'Excited', 'Calm', 'Curious','love' , 'Nervous', 'Lonely', 'Stressed', 'Confused', 'Angry', 'Sad', 'Motivated', 'Tired', 'Proud').",
                  },
                  extractedMemories: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Strictly new factual details explicitly shared by the user in this message to remember (e.g., 'Has a pet dog named Max', 'Birthday is Dec 5th'). Do not duplicate existing memories. Leave empty if no new details are present.",
                  },
                  suggestedActivities: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "2 or 3 fun activity suggestions that match the vibe of the conversation (e.g., Creative writing, Quiz game, Daily reflection, Journal prompts, Storytelling).",
                  }
                },
                required: ["reply", "detectedMood", "extractedMemories", "suggestedActivities"]
              }
            }
          });
          
          if (response) {
            console.log(`Gemini generation succeeded with model: ${modelName}`);
            break;
          }
        } catch (err: any) {
          console.warn(`Model ${modelName} failed or is currently busy. Error details:`, err.message || err);
          lastError = err;
        }
      }

      if (!response) {
        throw lastError || new Error("All high-availability fallback models in the chain failed.");
      }

      const resultText = response.text || "{}";
      const resultJson = cleanAndParseJSON(resultText);
      res.json(resultJson);

    } catch (error: any) {
      console.error("Error in /api/chat:", error);
      res.status(500).json({ error: error.message || "An error occurred during generating content." });
    }
  });
  // Serve Vite files
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Failed to start server:", err);
});
