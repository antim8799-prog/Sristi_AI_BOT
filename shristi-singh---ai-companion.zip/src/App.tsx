import React, { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Sparkles, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Smile, 
  Trash2, 
  Plus, 
  Heart, 
  User, 
  Settings, 
  RefreshCw, 
  Brain, 
  Compass, 
  Search, 
  X, 
  Activity,
  Award,
  BookMarked,
  MessageCircle,
  Clock,
  Mic,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Message, UserProfile, Memory, UserMood } from "./types";

// Predefined fallback activities to suggest when chat starts
const DEFAULT_ACTIVITIES = [
  "Storytelling",
  "Daily reflection",
  "Quiz game",
  "Movie recommendations",
  "Goal planning",
  "Language practice"
];

// Map moods to warm descriptions, visual gradient classes, and emoji insights
const MOOD_METADATA: Record<UserMood, { label: string; text: string; bg: string; border: string; glow: string; quote: string }> = {
  Happy: {
    label: "Happy",
    text: "text-amber-600",
    bg: "bg-amber-500",
    border: "border-amber-200",
    glow: "shadow-[0_0_20px_rgba(245,158,11,0.5)]",
    quote: "You have a vibrant, happy aura today! Let's celebrate this high energy."
  },
  Excited: {
    label: "Excited",
    text: "text-orange-600",
    bg: "bg-orange-500",
    border: "border-orange-200",
    glow: "shadow-[0_0_20px_rgba(249,115,22,0.6)]",
    quote: "Your energy is buzzing! Tell me more about what's making you excited."
  },
  Calm: {
    label: "Calm",
    text: "text-emerald-600",
    bg: "bg-emerald-500",
    border: "border-emerald-200",
    glow: "shadow-[0_0_20px_rgba(16,185,129,0.4)]",
    quote: "Such a peaceful mind. Perfect time for deep thinking or quiet reflection."
  },
  Curious: {
    label: "Curious",
    text: "text-indigo-600",
    bg: "bg-indigo-500",
    border: "border-indigo-200",
    glow: "shadow-[0_0_20px_rgba(99,102,241,0.5)]",
    quote: "A curious mind is an growing mind. Ask me anything, or let's explore together!"
  },
  Nervous: {
    label: "Nervous",
    text: "text-yellow-600",
    bg: "bg-yellow-400",
    border: "border-yellow-200",
    glow: "shadow-[0_0_20px_rgba(234,179,8,0.4)]",
    quote: "Take a deep breath. You are in a safe space; we can take things one step at a time."
  },
  Lonely: {
    label: "Lonely",
    text: "text-sky-600",
    bg: "bg-sky-400",
    border: "border-sky-200",
    glow: "shadow-[0_0_20px_rgba(56,189,248,0.5)]",
    quote: "I'm right here with you. You are never fully alone while we can share this chat."
  },
  Stressed: {
    label: "Stressed",
    text: "text-rose-600",
    bg: "bg-rose-500",
    border: "border-rose-200",
    glow: "shadow-[0_0_20px_rgba(244,63,94,0.5)]",
    quote: "Let's release some of that pressure. You don't have to carry everything alone."
  },
  Confused: {
    label: "Confused",
    text: "text-purple-600",
    bg: "bg-purple-500",
    border: "border-purple-200",
    glow: "shadow-[0_0_20px_rgba(168,85,247,0.4)]",
    quote: "Let's untangle these thoughts together. Sometimes writing it out brings clarity."
  },
  Angry: {
    label: "Angry",
    text: "text-red-700",
    bg: "bg-red-600",
    border: "border-red-200",
    glow: "shadow-[0_0_20px_rgba(220,38,38,0.5)]",
    quote: "It's completely okay to feel mad. Vent to me as much as you need."
  },
  Sad: {
    label: "Sad",
    text: "text-blue-600",
    bg: "bg-blue-500",
    border: "border-blue-200",
    glow: "shadow-[0_0_20px_rgba(59,130,246,0.5)]",
    quote: "I hear your sadness, and I'm sending you the warmest comfort. Take your time."
  },
  Motivated: {
    label: "Motivated",
    text: "text-teal-600",
    bg: "bg-teal-500",
    border: "border-teal-200",
    glow: "shadow-[0_0_20px_rgba(20,184,166,0.5)]",
    quote: "Keep that flame burning! Let's tackle some goals or brainstorm creative ideas."
  },
  Tired: {
    label: "Tired",
    text: "text-slate-600",
    bg: "bg-slate-400",
    border: "border-slate-200",
    glow: "shadow-[0_0_15px_rgba(148,163,184,0.3)]",
    quote: "You have worked hard. Make sure to rest, sip some tea, and go easy on yourself."
  },
  Proud: {
    label: "Proud",
    text: "text-violet-600",
    bg: "bg-violet-500",
    border: "border-violet-200",
    glow: "shadow-[0_0_20px_rgba(139,92,246,0.5)]",
    quote: "You did it! I'm genuinely proud of your progress. Every step counts!"
  }
};

export default function App() {
  // Load state from localStorage on initialize
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem("shristi_messages");
    return saved ? JSON.parse(saved) : [];
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem("shristi_profile");
    return saved ? JSON.parse(saved) : {
      name: "Antim Yadav",
      birthday: "",
      preferredLength: "Medium",
      humorPreference: "Playful"
    };
  });

  const [memories, setMemories] = useState<Memory[]>(() => {
    const saved = localStorage.getItem("shristi_memories");
    return saved ? JSON.parse(saved) : [];
  });

  const [activeActivity, setActiveActivity] = useState<string>(() => {
    return localStorage.getItem("shristi_active_activity") || "";
  });

  const [detectedMood, setDetectedMood] = useState<UserMood>("Calm");
  const [suggestedActivities, setSuggestedActivities] = useState<string[]>(DEFAULT_ACTIVITIES);
  const [isTyping, setIsTyping] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [memoryEnabled, setMemoryEnabled] = useState(true);
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const saved = localStorage.getItem("shristi_theme");
    return (saved as "light" | "dark") || "light";
  });

  // UI state toggles
  const [activeTab, setActiveTab] = useState<"chat" | "memories" | "settings">("chat");
  const [searchMemoryQuery, setSearchMemoryQuery] = useState("");
  const [newMemoryInput, setNewMemoryInput] = useState("");
  const [memoryCategory, setMemoryCategory] = useState<Memory["category"]>("General");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editingNameValue, setEditingNameValue] = useState(profile.name);

  // References
  const chatEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem("shristi_messages", JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem("shristi_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem("shristi_memories", JSON.stringify(memories));
  }, [memories]);

  useEffect(() => {
    localStorage.setItem("shristi_active_activity", activeActivity);
  }, [activeActivity]);

  useEffect(() => {
    localStorage.setItem("shristi_theme", theme);
  }, [theme]);

  // Handle first turn greeting if no messages exist
  useEffect(() => {
    if (messages.length === 0) {
      const firstGreeting = `Hi, Antim! I'm Shristi Singh, your girlfriend. 🌸 I am so happy to chat with you! I'm here to listen, support your goals, laugh together, and grow with you over time. 

Tell me, Antim, how is your day going? We can also try out some fun shared activities from the activities chest whenever you're ready!`;
      
      setMessages([
        {
          id: "welcome-msg",
          role: "assistant",
          content: firstGreeting,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [messages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Toast notifier helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Text-To-Speech audio player styled as a 20-year-old girl in Indian Accent
  const playSpeech = (text: string) => {
    if (!voiceEnabled || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      // Remove basic markdown formatting for readable speaking
      const plainText = text
        .replace(/[*#_`~]/g, "")
        .replace(/https?:\/\/\S+/g, "")
        .replace(/[:)-]/g, "");

      const utterance = new SpeechSynthesisUtterance(plainText);
      const voices = window.speechSynthesis.getVoices();
      
      // Find Indian accent female/young voices first (en-IN / hi-IN / India)
      let preferredVoice = voices.find(v => {
        const name = v.name.toLowerCase();
        const lang = v.lang.toLowerCase();
        const isIndian = lang.includes("hi-in") || name.includes("india");
        const isFemale = name.includes("female") || name.includes("priya") || name.includes("pallavi") || name.includes("heera") || name.includes("sangeeta") || name.includes("neerja") || name.includes("pallavi") || name.includes("swara") || name.includes("girl");
        return isIndian && isFemale;
      });

      // Fallback 1: Any Indian voice (e.g. Rishi, Google India male, etc.)
      if (!preferredVoice) {
        preferredVoice = voices.find(v => {
          const name = v.name.toLowerCase();
          const lang = v.lang.toLowerCase();
          return lang.includes("hi-in") || name.includes("india");
        });
      }

      // Fallback 2: General young female voices (e.g. Samantha, Zira, Google US English, Victoria, Tessa)
      // if (!preferredVoice) {
      //   preferredVoice = voices.find(v => {
      //     const name = v.name.toLowerCase();
      //     return name.includes("female") || name.includes("samantha") || name.includes("zira") || name.includes("victoria") || name.includes("tessa") || name.includes("priya");
      //   });
      // }

      // Fallback 3: Standard first available voice
      if (!preferredVoice && voices.length > 0) {
        preferredVoice = voices[0];
      }

      if (preferredVoice) {
        utterance.voice = preferredVoice;
        console.log("Selected companion voice:", preferredVoice.name, preferredVoice.lang);
      }
      
      // Tuning parameters to resemble a 20-year-old energetic & cheerful girl:
      // - Rate of 1.05 makes it sound natural, youthful, and responsive (not too slow/sleepy).
      // - Pitch of 1.20 adds a youthful, light, feminine brightness to any system voice.
      utterance.rate = 1.05; 
      utterance.pitch = 1.20; 
      
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error("Speech Synthesis failed:", err);
    }
  };

  // Cancel speech synthesis on unmount or toggle off
  useEffect(() => {
    if (!voiceEnabled) {
      window.speechSynthesis.cancel();
    }
  }, [voiceEnabled]);

  // Main sendMessage routine
  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText ? customText.trim() : inputValue.trim();
    if (!textToSend) return;

    if (!customText) {
      setInputValue("");
    }

    // Append user's message
    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setIsTyping(true);

    try {
      // Build request body for backend
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedMessages.slice(-10), // send last 10 messages for context
          userProfile: profile,
          userMemories: memoryEnabled ? memories.map(m => m.fact) : [],
          activeActivity: activeActivity
        })
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with Shristi ji. Please ensure your Gemini key is valid.");
      }

      const data = await response.json();

      // Destructure structured response
      const { reply, detectedMood: incomingMood, extractedMemories, suggestedActivities: incomingActivities } = data;

      // Create assistant message
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: reply || "I'm here for you, but my response came back empty. Let's try saying that again?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);

      // Trigger text-to-speech if active
      if (voiceEnabled) {
        playSpeech(reply);
      }

      // Handle newly extracted memories automatically
      if (memoryEnabled && Array.isArray(extractedMemories) && extractedMemories.length > 0) {
        const addedMemories: Memory[] = [];
        extractedMemories.forEach((fact: string) => {
          // Prevent duplicates
          const exists = memories.some(m => m.fact.toLowerCase() === fact.toLowerCase());
          if (!exists) {
            addedMemories.push({
              id: Math.random().toString(36).substr(2, 9),
              fact,
              category: determineCategory(fact),
              createdAt: new Date().toLocaleDateString()
            });
          }
        });

        if (addedMemories.length > 0) {
          setMemories(prev => [...prev, ...addedMemories]);
          triggerToast(`🌸 Shristi noted a new memory: "${addedMemories[0].fact}"`);
        }
      }

      // Update interactive metadata
      if (incomingMood) {
        setDetectedMood(incomingMood as UserMood);
      }
      if (Array.isArray(incomingActivities) && incomingActivities.length > 0) {
        setSuggestedActivities(incomingActivities);
      }

    } catch (err: any) {
      console.error(err);
      const errMsg: Message = {
        id: (Date.now() + 2).toString(),
        role: "assistant",
        content: `I'm having a little trouble connecting right now: ${err.message || "Unknown error"}. Feel free to double-check the API configuration, or try again in a moment! I'm ready when you are.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  // Basic category heuristic helper
  const determineCategory = (fact: string): Memory["category"] => {
    const text = fact.toLowerCase();
    if (text.includes("favorite") || text.includes("love") || text.includes("music") || text.includes("movie") || text.includes("song") || text.includes("artist") || text.includes("food")) {
      return "Favorites";
    }
    if (text.includes("goal") || text.includes("dream") || text.includes("hobby") || text.includes("learn") || text.includes("skill") || text.includes("coding")) {
      return "Goals & Hobbies";
    }
    if (text.includes("daily") || text.includes("routine") || text.includes("sleep") || text.includes("work") || text.includes("career") || text.includes("academic") || text.includes("birthday") || text.includes("bday")) {
      return "Life & Routine";
    }
    return "General";
  };

  // Start specific shared activity
  const startSharedActivity = (activityName: string) => {
    setActiveActivity(activityName);
    setActiveTab("chat");
    const introText = `I'd love to start the "${activityName}" activity with you! Let's do it! How do we begin?`;
    handleSendMessage(introText);
  };

  // End active activity
  const endSharedActivity = () => {
    const oldActivity = activeActivity;
    setActiveActivity("");
    triggerToast(`Ended the "${oldActivity}" activity.`);
    handleSendMessage(`Let's take a break from the ${oldActivity} activity now and just chat freely.`);
  };

  // Add custom memory manually
  const handleAddMemoryManually = () => {
    if (!newMemoryInput.trim()) return;
    const newMem: Memory = {
      id: Math.random().toString(36).substr(2, 9),
      fact: newMemoryInput.trim(),
      category: memoryCategory,
      createdAt: new Date().toLocaleDateString()
    };
    setMemories(prev => [...prev, newMem]);
    setNewMemoryInput("");
    triggerToast("Saved custom memory to the ledger!");
  };

  // Delete a memory
  const handleDeleteMemory = (id: string) => {
    setMemories(prev => prev.filter(m => m.id !== id));
    triggerToast("Memory removed from ledger.");
  };

  // Clear all conversation logs
  const handleResetConversation = () => {
    if (window.confirm("Are you sure you want to clear our chat history? I'll still remember your memories and preferences!")) {
      setMessages([]);
      setActiveActivity("");
      setDetectedMood("Calm");
      setSuggestedActivities(DEFAULT_ACTIVITIES);
      triggerToast("Chat history cleared. Started fresh conversation!");
    }
  };

  // Update name editor values
  const handleSaveName = () => {
    const trimmed = editingNameValue.trim();
    setProfile(prev => ({ ...prev, name: trimmed }));
    setIsEditingName(false);
    triggerToast(trimmed ? `Profile updated! I'll call you ${trimmed} from now on.` : "Profile updated!");
  };

  // Filter memories matching query
  const filteredMemories = memories.filter(m => 
    m.fact.toLowerCase().includes(searchMemoryQuery.toLowerCase()) ||
    m.category.toLowerCase().includes(searchMemoryQuery.toLowerCase())
  );

  const activeMoodMeta = MOOD_METADATA[detectedMood] || MOOD_METADATA.Calm;

  return (
    <div id="root-container" className={`flex flex-col lg:flex-row h-screen w-screen font-sans overflow-hidden transition-colors duration-300 ${
      theme === "dark" 
        ? "bg-slate-950 text-slate-100" 
        : "bg-[#fbf9f4] text-slate-800"
    }`}>
      
      {/* Dynamic Toast Alert */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50 bg-slate-950 text-white px-5 py-3 rounded-full text-xs font-medium flex items-center gap-2 shadow-xl border border-slate-800/50"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* LEFT SIDEBAR: Companion Persona & Dynamics (Collapsible / Static on desktop) */}
      <aside id="companion-sidebar" className={`w-full lg:w-[360px] xl:w-[380px] border-b lg:border-b-0 lg:border-r flex flex-col flex-shrink-0 transition-colors duration-300 ${
        theme === "dark" 
          ? "bg-slate-900 border-slate-800" 
          : "bg-[#f5efe4] border-amber-900/10"
      }`}>
        
        {/* Sidebar Header */}
        <div className={`p-6 pb-4 border-b flex items-center justify-between transition-colors duration-300 ${
          theme === "dark" ? "border-slate-850" : "border-amber-900/5"
        }`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full text-white flex items-center justify-center font-serif text-lg font-bold shadow-md ${
              theme === "dark" ? "bg-amber-600" : "bg-amber-700"
            }`}>
              SS
            </div>
            <div>
              <h1 id="companion-title" className={`font-serif font-bold text-lg tracking-tight leading-tight transition-colors ${
                theme === "dark" ? "text-slate-100" : "text-amber-950"
              }`}>Shristi Singh</h1>
              <span id="companion-subtitle" className={`text-xs font-medium tracking-wide uppercase ${
                theme === "dark" ? "text-amber-400" : "text-amber-800"
              }`}>Your AI GirlFriend</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`p-2 rounded-full transition-all duration-300 ${
                voiceEnabled 
                  ? 'bg-amber-650 text-white shadow-md' 
                  : (theme === "dark" ? 'bg-slate-800 text-slate-300 hover:bg-slate-750' : 'bg-amber-100 text-amber-900 hover:bg-amber-200')
              }`}
              title={voiceEnabled ? "Voice enabled - Shristi will speak replies" : "Enable spoken replies"}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Dynamic Mood Orb & Status */}
        <div className={`p-6 pb-4 border-b flex flex-col items-center text-center transition-colors duration-300 ${
          theme === "dark" ? "bg-slate-900/60 border-slate-800" : "bg-amber-50/50 border-amber-900/5"
        }`}>
          <div className="relative mb-3">
            {/* Glowing outer aura */}
            <div className={`absolute inset-0 rounded-full blur-xl opacity-40 transition-all duration-700 ${activeMoodMeta.bg} ${activeMoodMeta.glow}`}></div>
            {/* Pulsing inner Orb */}
            <motion.div
              animate={{ scale: [1, 1.06, 1] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className={`w-16 h-16 rounded-full flex items-center justify-center border-4 ${activeMoodMeta.border} relative z-10 transition-colors duration-700 ${activeMoodMeta.bg}`}
            >
              <Heart className="w-6 h-6 text-white fill-white/20 animate-pulse" />
            </motion.div>
          </div>
          
          <span className={`text-[10px] font-bold tracking-widest uppercase ${theme === "dark" ? "text-amber-400" : "text-amber-800"}`}>Detected Energy Aura</span>
          <h3 id="aura-label" className={`font-serif font-bold text-xl mt-0.5 ${activeMoodMeta.text}`}>{activeMoodMeta.label}</h3>
          <p id="aura-quote" className={`text-xs mt-2 max-w-xs leading-relaxed italic ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            "{activeMoodMeta.quote}"
          </p>
        </div>

        {/* Tab Selection */}
        <div className={`grid grid-cols-3 p-1 gap-1 m-3 rounded-lg border transition-colors duration-300 ${
          theme === "dark" ? "bg-slate-950/45 border-slate-800" : "bg-amber-50/30 border-amber-900/5"
        }`}>
          <button
            onClick={() => setActiveTab("chat")}
            className={`py-2 text-[10px] sm:text-xs font-semibold rounded-md flex flex-col sm:flex-row items-center justify-center gap-1 transition-all ${
              activeTab === "chat" 
                ? (theme === "dark" ? 'bg-slate-800 text-amber-400 shadow-sm' : 'bg-white text-amber-950 shadow-sm') 
                : (theme === "dark" ? 'text-slate-400 hover:bg-slate-800/50' : 'text-amber-900 hover:bg-white/50')
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chat</span>
          </button>
          <button
            onClick={() => setActiveTab("memories")}
            className={`py-2 text-[10px] sm:text-xs font-semibold rounded-md flex flex-col sm:flex-row items-center justify-center gap-1 transition-all ${
              activeTab === "memories" 
                ? (theme === "dark" ? 'bg-slate-800 text-amber-400 shadow-sm' : 'bg-white text-amber-950 shadow-sm') 
                : (theme === "dark" ? 'text-slate-400 hover:bg-slate-800/50' : 'text-amber-900 hover:bg-white/50')
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            <span>Memories ({memories.length})</span>
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`py-2 text-[10px] sm:text-xs font-semibold rounded-md flex flex-col sm:flex-row items-center justify-center gap-1 transition-all ${
              activeTab === "settings" 
                ? (theme === "dark" ? 'bg-slate-800 text-amber-400 shadow-sm' : 'bg-white text-amber-950 shadow-sm') 
                : (theme === "dark" ? 'text-slate-400 hover:bg-slate-800/50' : 'text-amber-900 hover:bg-white/50')
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>
        </div>

        {/* Sidebar Content Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 pt-1 space-y-4">
          
          {/* Active Activity Panel */}
          {activeActivity && (
            <div id="active-activity-banner" className="bg-amber-800 text-amber-50 p-4 rounded-xl shadow-md border border-amber-900/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2 opacity-10">
                <Compass className="w-16 h-16" />
              </div>
              <div className="relative z-10">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-ping"></span>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-200">Shared Session Active</span>
                </div>
                <h4 className="font-serif font-bold text-base">{activeActivity}</h4>
                <p className="text-xs text-amber-100/80 mt-1 leading-relaxed">
                  Shristi is currently guiding this activity with you. Have fun!
                </p>
                <button
                  onClick={endSharedActivity}
                  className="mt-3 bg-amber-50 text-amber-950 font-semibold px-3 py-1.5 rounded-lg text-xs hover:bg-amber-100 transition shadow-sm flex items-center gap-1"
                >
                  <X className="w-3 h-3 text-red-600" />
                  End Activity
                </button>
              </div>
            </div>
          )}

          {/* Quick activities selection when chat tab is active */}
          {activeTab === "chat" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <span className={`text-[11px] font-bold uppercase tracking-widest flex items-center gap-1 ${
                  theme === "dark" ? "text-amber-400" : "text-amber-900"
                }`}>
                  <Compass className="w-3.5 h-3.5" />
                  Activities Chest
                </span>
                <span className="text-[10px] text-slate-500 italic">Click to launch</span>
              </div>
              
              <div id="activity-grid" className="grid grid-cols-2 gap-2">
                {[
                  { name: "Storytelling", desc: "Cozy co-created stories", icon: BookMarked },
                  { name: "Daily reflection", desc: "Review your day warmly", icon: Clock },
                  { name: "Quiz game", desc: "Interactive fun trivia", icon: Award },
                  { name: "Movie suggestions", desc: "Find your next watch", icon: Compass },
                  { name: "Goal planning", desc: "Break down ambitions", icon: Activity },
                  { name: "Language practice", desc: "Friendly conversations", icon: User }
                ].map((act, index) => {
                  const IconComp = act.icon;
                  return (
                    <button
                      key={index}
                      onClick={() => startSharedActivity(act.name)}
                      className={`p-3 text-left border rounded-xl transition-all duration-200 group flex flex-col justify-between h-[84px] shadow-sm hover:shadow ${
                        theme === "dark" 
                          ? "bg-slate-950/60 border-slate-800 hover:bg-slate-800 hover:border-amber-500/30" 
                          : "bg-white hover:bg-amber-50 hover:border-amber-400/40 border-slate-200/60"
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <IconComp className={`w-4 h-4 group-hover:text-amber-400 transition-colors ${
                          theme === "dark" ? "text-amber-400" : "text-amber-800"
                        }`} />
                        <ArrowRight className="w-3 h-3 text-slate-300 opacity-0 group-hover:opacity-100 group-hover:text-amber-500 transition-all transform translate-x-1" />
                      </div>
                      <div>
                        <h5 className={`text-xs font-semibold leading-tight ${
                          theme === "dark" ? "text-slate-200" : "text-slate-900"
                        }`}>{act.name}</h5>
                        <p className={`text-[9px] mt-0.5 line-clamp-1 ${
                          theme === "dark" ? "text-slate-400" : "text-slate-500"
                        }`}>{act.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Memory tab quick summary */}
          {activeTab === "memories" && (
            <div className="space-y-3">
              <div className={`p-4 rounded-xl border shadow-sm ${
                theme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200/60"
              }`}>
                <h4 className={`text-xs font-bold flex items-center gap-1.5 mb-1 ${
                  theme === "dark" ? "text-amber-400" : "text-amber-950"
                }`}>
                  <Brain className={`w-4 h-4 ${theme === "dark" ? "text-amber-400" : "text-amber-800"}`} />
                  How memory works
                </h4>
                <p className={`text-[11px] leading-relaxed ${theme === "dark" ? "text-slate-300" : "text-slate-600"}`}>
                  Shristi automatically listens for facts you explicitly share (like your name, favorite foods, birthdays, dreams). They are saved securely in your browser's memory and automatically fed to Shristi to ensure she is personalized and responsive!
                </p>
                <div className={`mt-3 flex items-center justify-between pt-3 border-t ${
                  theme === "dark" ? "border-slate-800" : "border-slate-100"
                }`}>
                  <span className={`text-[11px] font-semibold ${theme === "dark" ? "text-slate-300" : "text-slate-700"}`}>Memory Engine State</span>
                  <button
                    onClick={() => setMemoryEnabled(!memoryEnabled)}
                    className={`text-xs px-3 py-1 rounded-full font-semibold transition-all ${
                      memoryEnabled 
                        ? (theme === "dark" ? 'bg-emerald-900/40 text-emerald-300' : 'bg-emerald-100 text-emerald-800') 
                        : (theme === "dark" ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600')
                    }`}
                  >
                    {memoryEnabled ? "Active & Syncing" : "Paused / Private"}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Settings / Profile Preview */}
          {activeTab === "settings" && (
            <div className={`p-4 rounded-xl border shadow-sm space-y-4 ${
              theme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200/60"
            }`}>
              <h4 className={`text-xs font-bold flex items-center gap-1.5 ${
                theme === "dark" ? "text-amber-400" : "text-amber-950"
              }`}>
                <User className={`w-4 h-4 ${theme === "dark" ? "text-amber-400" : "text-amber-800"}`} />
                Companion Profile
              </h4>
              <p className={`text-[11px] ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>
                Customize how Shristi Singh communicates, adapts her humor, and structures her warmth for you.
              </p>
              
              <div className="space-y-3 pt-2">
                {/* DP / Profile Photo Upload Section */}
                <div>
                  <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1.5 ${
                    theme === "dark" ? "text-amber-400" : "text-amber-950"
                  }`}>Your Photo / Display Picture (DP)</label>
                  <div className="flex items-center gap-3">
                    <div className="relative group">
                      {profile.avatarUrl ? (
                        <img 
                          src={profile.avatarUrl} 
                          alt="Your Photo" 
                          className="w-12 h-12 rounded-full object-cover border-2 border-amber-650 shadow-md"
                        />
                      ) : (
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-sm font-bold shadow-md border ${
                          theme === "dark" ? "bg-slate-800 border-slate-700 text-amber-400" : "bg-amber-100 border-amber-200 text-amber-900"
                        }`}>
                          {profile.name ? profile.name.slice(0, 2).toUpperCase() : "ME"}
                        </div>
                      )}
                    </div>
                    <div className="flex-1 space-y-1">
                      <label className={`block text-[10px] font-semibold py-1 px-2.5 rounded-lg border text-center cursor-pointer transition ${
                        theme === "dark" 
                          ? "bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200" 
                          : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                      }`}>
                        <span>Upload Photo</span>
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              if (file.size > 2 * 1024 * 1024) {
                                triggerToast("Image must be smaller than 2MB");
                                return;
                              }
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                setProfile(prev => ({ ...prev, avatarUrl: reader.result as string }));
                                triggerToast("Display picture updated successfully! 🌸");
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          className="hidden" 
                        />
                      </label>
                      {profile.avatarUrl && (
                        <button
                          onClick={() => {
                            setProfile(prev => {
                              const copy = { ...prev };
                              delete copy.avatarUrl;
                              return copy;
                            });
                            triggerToast("Display picture removed.");
                          }}
                          className="block w-full text-[9px] text-red-500 hover:underline text-center font-semibold animate-fade-in"
                        >
                          Remove Photo
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Theme Selection toggle in sidebar */}
                <div className={`pt-2 border-t ${theme === "dark" ? "border-slate-800/80" : "border-slate-100"}`}>
                  <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1.5 ${
                    theme === "dark" ? "text-amber-400" : "text-amber-950"
                  }`}>Theme Selection</label>
                  <div className={`grid grid-cols-2 gap-1.5 p-1 rounded-lg ${
                    theme === "dark" ? "bg-slate-950" : "bg-slate-100"
                  }`}>
                    <button
                      onClick={() => setTheme("light")}
                      className={`py-1 text-xs font-semibold rounded-md transition ${
                        theme === "light" 
                          ? 'bg-white text-amber-950 shadow-xs' 
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      ☀️ Light
                    </button>
                    <button
                      onClick={() => setTheme("dark")}
                      className={`py-1 text-xs font-semibold rounded-md transition ${
                        theme === "dark" 
                          ? 'bg-slate-800 text-amber-400 shadow-xs' 
                          : 'text-slate-600 hover:text-slate-400'
                      }`}
                    >
                      🌙 Dark
                    </button>
                  </div>
                </div>

                <div>
                  <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1 ${
                    theme === "dark" ? "text-amber-400" : "text-amber-900"
                  }`}>Your Name</label>
                  {isEditingName ? (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={editingNameValue}
                        onChange={(e) => setEditingNameValue(e.target.value)}
                        className={`flex-1 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none ${
                          theme === "dark" 
                            ? "bg-slate-950 border border-slate-800 text-slate-100 focus:border-amber-500" 
                            : "bg-slate-50 border border-slate-200 text-slate-900 focus:border-amber-600"
                        }`}
                        placeholder="Enter your name..."
                        maxLength={40}
                      />
                      <button
                        onClick={handleSaveName}
                        className={`text-xs font-semibold px-3 py-1 rounded-lg ${
                          theme === "dark" ? "bg-amber-600 text-white" : "bg-amber-800 text-white"
                        }`}
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <div className={`flex items-center justify-between px-3 py-2 rounded-lg border ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-100"
                    }`}>
                      <span className={`text-xs font-semibold ${theme === "dark" ? "text-slate-200" : "text-slate-900"}`}>{profile.name || "Friend (Not specified)"}</span>
                      <button
                        onClick={() => {
                          setEditingNameValue(profile.name);
                          setIsEditingName(true);
                        }}
                        className={`text-[10px] font-bold hover:underline ${theme === "dark" ? "text-amber-400" : "text-amber-800"}`}
                      >
                        Edit
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1 ${
                    theme === "dark" ? "text-amber-400" : "text-amber-900"
                  }`}>Response Length</label>
                  <div className={`grid grid-cols-3 gap-1 p-1 rounded-lg ${
                    theme === "dark" ? "bg-slate-950" : "bg-slate-100"
                  }`}>
                    {["Short", "Medium", "Long"].map((len) => (
                      <button
                        key={len}
                        onClick={() => setProfile(prev => ({ ...prev, preferredLength: len as any }))}
                        className={`py-1 text-[10px] font-bold rounded-md transition ${
                          profile.preferredLength === len 
                            ? (theme === "dark" ? 'bg-slate-800 text-amber-400 shadow-xs' : 'bg-white text-amber-950 shadow-xs') 
                            : (theme === "dark" ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900')
                        }`}
                      >
                        {len}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className={`text-[10px] font-bold uppercase tracking-wider block mb-1 ${
                    theme === "dark" ? "text-amber-400" : "text-amber-900"
                  }`}>Humor Style</label>
                  <div className={`grid grid-cols-3 gap-1 p-1 rounded-lg ${
                    theme === "dark" ? "bg-slate-950" : "bg-slate-100"
                  }`}>
                    {["Gentle", "Playful", "Sarcastic"].map((hum) => (
                      <button
                        key={hum}
                        onClick={() => setProfile(prev => ({ ...prev, humorPreference: hum as any }))}
                        className={`py-1 text-[10px] font-bold rounded-md transition ${
                          profile.humorPreference === hum 
                            ? (theme === "dark" ? 'bg-slate-800 text-amber-400 shadow-xs' : 'bg-white text-amber-950 shadow-xs') 
                            : (theme === "dark" ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900')
                        }`}
                      >
                        {hum}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Sidebar Footer Info */}
        <div className={`p-4 border-t text-center flex flex-col gap-1.5 transition-colors ${
          theme === "dark" ? "bg-slate-950/40 border-slate-800" : "bg-amber-100/30 border-amber-900/5"
        }`}>
          <span className={`text-[9px] font-semibold uppercase tracking-wider ${
            theme === "dark" ? "text-amber-400" : "text-amber-900/60"
          }`}>Shristi Singh Companion v1.2</span>
          <div className="flex justify-center gap-4">
            <button
              onClick={handleResetConversation}
              className="text-[10px] font-bold text-red-700 hover:text-red-900 flex items-center gap-1 hover:underline transition-colors"
            >
              <RefreshCw className="w-3 h-3 animate-spin-slow" />
              Reset Conversation
            </button>
          </div>
        </div>

      </aside>

      {/* MAIN WORKSPACE AREA: Dynamic depending on Active Tab */}
      <main id="main-workspace" className={`flex-1 flex flex-col h-full overflow-hidden relative transition-colors duration-300 ${
        theme === "dark" ? "bg-slate-950 text-slate-100" : "bg-[#fdfdfc]"
      }`}>
        
        {/* TAB 1: Chat Workspace */}
        {activeTab === "chat" && (
          <div id="chat-workspace-panel" className="flex-1 flex flex-col h-full overflow-hidden">
            
            {/* Top Workspace status bar */}
            <header className={`px-6 py-4 border-b flex items-center justify-between shadow-xs z-10 transition-colors duration-300 ${
              theme === "dark" ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            }`}>
              <div>
                <h2 id="workspace-header-title" className={`font-serif font-bold text-base leading-tight ${
                  theme === "dark" ? "text-slate-100" : "text-slate-950"
                }`}>
                  {activeActivity ? `Session: ${activeActivity}` : "Dialogue Space"}
                </h2>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span className={`text-[10px] font-medium ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>Shristi is listening closely</span>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Voice mode visual status */}
                <button
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition ${
                    voiceEnabled 
                      ? (theme === "dark" ? "bg-amber-950/60 text-amber-400 border-amber-900/50" : "bg-amber-50 text-amber-950 border-amber-200") 
                      : (theme === "dark" ? "bg-slate-850 text-slate-400 border-slate-800 hover:bg-slate-800" : "bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100")
                  }`}
                >
                  <Volume2 className={`w-3.5 h-3.5 ${voiceEnabled ? 'text-amber-400 animate-bounce' : 'text-slate-400'}`} />
                  <span>{voiceEnabled ? "Voice Mode ON" : "Mute Response"}</span>
                </button>
              </div>
            </header>

            {/* Scrolling Conversation Area */}
            <div 
              ref={scrollContainerRef}
              id="chat-scroll-container" 
              className={`flex-1 overflow-y-auto px-6 py-8 space-y-6 transition-colors duration-300 ${
                theme === "dark" 
                  ? "bg-slate-950 bg-gradient-to-b from-slate-950 to-slate-900" 
                  : "bg-gradient-to-b from-[#fdfbf7] to-[#fbf9f4]"
              }`}
            >
              <AnimatePresence initial={false}>
                {messages.map((msg, i) => {
                  const isAssistant = msg.role === "assistant";
                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${isAssistant ? "justify-start" : "justify-end"} w-full`}
                    >
                      <div className={`flex gap-3 max-w-[85%] md:max-w-[70%] ${isAssistant ? "flex-row" : "flex-row-reverse"}`}>
                        {/* Speaker Initials circle */}
                        <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center font-serif text-xs font-bold shadow-xs ${
                          isAssistant 
                            ? "bg-amber-700 text-amber-50" 
                            : (theme === "dark" ? "bg-slate-800 text-slate-250" : "bg-slate-900 text-white")
                        }`}>
                          {isAssistant ? "S" : (profile.name ? profile.name.slice(0, 2).toUpperCase() : "U")}
                        </div>
                        
                        <div className="space-y-1">
                          {/* Message box */}
                          <div className={`p-4 rounded-2xl leading-relaxed text-sm shadow-xs ${
                            isAssistant 
                              ? (theme === "dark" ? "bg-slate-900 text-slate-100 border border-slate-800 rounded-tl-none font-sans" : "bg-white text-slate-800 border border-slate-100 rounded-tl-none font-sans") 
                              : (theme === "dark" ? "bg-amber-650 text-white rounded-tr-none font-sans" : "bg-slate-900 text-white rounded-tr-none font-sans")
                          }`}>
                            {/* Line breaks format */}
                            {msg.content.split("\n").map((line, idx) => (
                              <p key={idx} className={line.trim() ? "mb-2 last:mb-0" : "h-3"}>
                                {line}
                              </p>
                            ))}
                          </div>
                          {/* Message timestamp & speaker tag */}
                          <div className={`flex items-center gap-1.5 text-[9px] text-slate-400 font-medium px-1 ${isAssistant ? "justify-start" : "justify-end"}`}>
                            <span>{isAssistant ? "Shristi" : (profile.name || "You")}</span>
                            <span>•</span>
                            <span>{msg.timestamp}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}

                {/* Companion Typing Indicator state */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start w-full"
                  >
                    <div className="flex gap-3 max-w-[85%]">
                      <div className="w-8 h-8 rounded-full bg-amber-700 text-amber-50 flex items-center justify-center font-serif text-xs font-bold animate-pulse">
                        S
                      </div>
                      <div className="space-y-1">
                        <div className={`border rounded-2xl rounded-tl-none p-4 flex items-center gap-1.5 shadow-xs transition-colors duration-300 ${
                          theme === "dark" ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
                        }`}>
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: "0ms" }}></span>
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: "150ms" }}></span>
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{ animationDelay: "300ms" }}></span>
                        </div>
                        <span className="text-[9px] text-slate-400 font-medium px-1">Shristi is reflecting...</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              <div ref={chatEndRef} />
            </div>

            {/* Suggested activities and topics pill row */}
            <div id="suggested-pills-row" className={`px-6 py-2.5 border-t flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-none transition-colors duration-300 ${
              theme === "dark" ? "bg-slate-900/80 border-slate-800" : "bg-amber-50/20 border-slate-100"
            }`}>
              <span className={`text-[10px] font-bold uppercase tracking-widest flex items-center gap-1 pr-1 border-r flex-shrink-0 ${
                theme === "dark" ? "text-amber-400 border-slate-800" : "text-amber-900 border-slate-200"
              }`}>
                <Sparkles className="w-3 h-3 text-amber-500" />
                Vibe Suggestions
              </span>
              <div className="flex gap-1.5">
                {suggestedActivities.map((act, index) => (
                  <button
                    key={index}
                    onClick={() => handleSendMessage(`Let's start the ${act} activity!`)}
                    className={`px-3 py-1 rounded-full border text-xs font-medium transition shadow-xs ${
                      theme === "dark" 
                        ? "bg-slate-950 hover:bg-slate-850 border-slate-800 text-slate-300 hover:text-amber-450 hover:border-amber-550/30" 
                        : "bg-white hover:bg-amber-50 border-slate-200 text-slate-700 hover:text-amber-950 hover:border-amber-400/40"
                    }`}
                  >
                    {act}
                  </button>
                ))}
              </div>
            </div>

            {/* Chat Input form footer */}
            <footer className={`p-4 md:p-6 border-t shadow-lg relative z-10 transition-colors duration-300 ${
              theme === "dark" ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            }`}>
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center gap-2 max-w-4xl mx-auto"
              >
                <div className="flex-1 relative flex items-center">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={activeActivity ? `Respond to Shristi in the ${activeActivity} activity...` : "Type a thoughtful response or vent your thoughts..."}
                    className={`w-full pl-4 pr-12 py-3.5 border rounded-2xl text-sm transition shadow-inner font-sans ${
                      theme === "dark" 
                        ? "bg-slate-950 border-slate-800 text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:bg-slate-950" 
                        : "bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-amber-600 focus:bg-white"
                    }`}
                    disabled={isTyping}
                  />
                  <div className="absolute right-3 flex items-center gap-1.5">
                    {inputValue.trim() && (
                      <button
                        type="submit"
                        className={`p-1.5 rounded-xl transition shadow-sm ${
                          theme === "dark" ? "bg-amber-600 text-white hover:bg-amber-550" : "bg-amber-800 text-white hover:bg-amber-900"
                        }`}
                        disabled={isTyping}
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </form>
            </footer>

          </div>
        )}


        {/* TAB 2: Memory Chest Workspace */}
        {activeTab === "memories" && (
          <div id="memory-chest-panel" className={`flex-1 flex flex-col h-full overflow-hidden transition-colors duration-300 ${
            theme === "dark" ? "bg-slate-950" : "bg-[#faf8f4]"
          }`}>
            
            {/* Header */}
            <header className={`px-6 py-4 border-b flex items-center justify-between shadow-xs transition-colors duration-300 ${
              theme === "dark" ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            }`}>
              <div>
                <h2 className={`font-serif font-bold text-base ${theme === "dark" ? "text-slate-100" : "text-slate-950"}`}>Memory Chest Ledger</h2>
                <p className={`text-xs ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>Inspect, search, and manage what Shristi remembers about you.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>{filteredMemories.length} item(s) found</span>
              </div>
            </header>

            {/* Search and manual memory insertion */}
            <div className="p-6 pb-2 grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Search bar */}
              <div className="relative flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3" />
                <input
                  type="text"
                  value={searchMemoryQuery}
                  onChange={(e) => setSearchMemoryQuery(e.target.value)}
                  placeholder="Search ledger by words or category..."
                  className={`w-full pl-9 pr-4 py-2.5 border rounded-xl text-xs focus:outline-none transition shadow-xs ${
                    theme === "dark" 
                      ? "bg-slate-900 border-slate-800 text-slate-200 focus:border-amber-500 placeholder:text-slate-550" 
                      : "bg-white border-slate-200 focus:border-amber-600 placeholder:text-slate-400 text-slate-800"
                  }`}
                />
              </div>

              {/* Add custom memory */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMemoryInput}
                  onChange={(e) => setNewMemoryInput(e.target.value)}
                  placeholder="Add a custom fact (e.g., 'Prefers Earl Grey tea')"
                  className={`flex-1 px-3 py-2.5 border rounded-xl text-xs focus:outline-none transition shadow-xs ${
                    theme === "dark" 
                      ? "bg-slate-900 border-slate-800 text-slate-250 focus:border-amber-500 placeholder:text-slate-500" 
                      : "bg-white border-slate-200 focus:border-amber-600 placeholder:text-slate-400 text-slate-800"
                  }`}
                />
                
                <select
                  value={memoryCategory}
                  onChange={(e) => setMemoryCategory(e.target.value as any)}
                  className={`border text-xs rounded-xl px-2.5 focus:outline-none shadow-xs ${
                    theme === "dark" 
                      ? "bg-slate-900 border-slate-800 text-slate-200 focus:border-amber-500" 
                      : "bg-white border-slate-200 focus:border-amber-600 text-slate-800"
                  }`}
                >
                  <option value="General">General</option>
                  <option value="Favorites">Favorites</option>
                  <option value="Goals & Hobbies">Goals</option>
                  <option value="Life & Routine">Routine</option>
                </select>

                <button
                  onClick={handleAddMemoryManually}
                  className={`font-semibold text-xs px-4 rounded-xl shadow transition flex items-center gap-1 flex-shrink-0 text-white ${
                    theme === "dark" ? "bg-amber-600 hover:bg-amber-550" : "bg-amber-800 hover:bg-amber-900"
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  Save
                </button>
              </div>

            </div>

            {/* Memories Listing */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              {filteredMemories.length === 0 ? (
                <div className={`flex flex-col items-center justify-center h-[280px] border border-dashed rounded-2xl p-6 text-center transition-colors duration-300 ${
                  theme === "dark" ? "bg-slate-900/40 border-slate-800" : "bg-white border-slate-200"
                }`}>
                  <Brain className="w-10 h-10 text-slate-500 mb-2 animate-pulse" />
                  <h4 className={`text-sm font-bold ${theme === "dark" ? "text-slate-200" : "text-slate-900"}`}>No Memories Saved Yet</h4>
                  <p className={`text-xs max-w-sm mt-1 ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>
                    Try chatting with Shristi and sharing some facts about yourself, or manually insert a fact above to get started!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  <AnimatePresence>
                    {filteredMemories.map((mem) => {
                      // pick category color badges
                      const badgeStyles = {
                        Favorites: theme === "dark" ? "bg-pink-950/60 text-pink-300 border-pink-900/60" : "bg-pink-50 text-pink-700 border-pink-200",
                        "Goals & Hobbies": theme === "dark" ? "bg-emerald-950/60 text-emerald-300 border-emerald-900/60" : "bg-emerald-50 text-emerald-700 border-emerald-200",
                        "Life & Routine": theme === "dark" ? "bg-sky-950/60 text-sky-300 border-sky-900/60" : "bg-sky-50 text-sky-700 border-sky-200",
                        General: theme === "dark" ? "bg-slate-800 text-slate-300 border-slate-700" : "bg-slate-50 text-slate-700 border-slate-200"
                      }[mem.category];

                      return (
                        <motion.div
                          key={mem.id}
                          layout
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className={`p-4 rounded-xl border shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 ${
                            theme === "dark" ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200/60 text-slate-800"
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${badgeStyles}`}>
                                {mem.category}
                              </span>
                              <span className="text-[9px] text-slate-400 font-medium">Added {mem.createdAt}</span>
                            </div>
                            <p className={`text-xs font-medium leading-relaxed font-sans ${theme === "dark" ? "text-slate-200" : "text-slate-800"}`}>{mem.fact}</p>
                          </div>
                          
                          <div className={`mt-4 pt-3 border-t flex justify-end ${theme === "dark" ? "border-slate-800" : "border-slate-100"}`}>
                            <button
                              onClick={() => handleDeleteMemory(mem.id)}
                              className={`p-1 rounded-lg transition ${
                                theme === "dark" ? "text-slate-400 hover:text-red-400 hover:bg-slate-800" : "text-slate-400 hover:text-red-600 hover:bg-red-50"
                              }`}
                              title="Delete Memory"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 3: settings/Profile Workspace */}
        {activeTab === "settings" && (
          <div id="settings-panel" className={`flex-1 flex flex-col h-full overflow-hidden p-6 transition-colors duration-300 ${
            theme === "dark" ? "bg-slate-950" : "bg-[#faf8f4]"
          }`}>
            <header className="mb-6">
              <h2 className={`font-serif font-bold text-xl ${theme === "dark" ? "text-slate-100" : "text-slate-950"}`}>Companion Preferences</h2>
              <p className={`text-xs ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>Fine-tune your relational preferences and profile options.</p>
            </header>

            <div className={`max-w-xl rounded-2xl border shadow-sm p-6 space-y-6 transition-colors duration-300 ${
              theme === "dark" ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200/60"
            }`}>
              <div>
                <h3 className={`text-sm font-bold mb-1 ${theme === "dark" ? "text-slate-200" : "text-slate-900"}`}>Interactive Quick-Actions</h3>
                <p className={`text-xs mb-3 ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>Reset options or start fresh conversation session parameters.</p>
                
                <div className="flex gap-3">
                  <button
                    onClick={handleResetConversation}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded-xl border border-red-200 transition flex items-center gap-1.5 shadow-xs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Reset Conversation History
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm("Do you want to completely erase all saved memories? Shristi won't remember past facts anymore!")) {
                        setMemories([]);
                        triggerToast("Erased all companion memories.");
                      }
                    }}
                    className="px-4 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-semibold rounded-xl border border-amber-200 transition flex items-center gap-1.5 shadow-xs"
                  >
                    <Brain className="w-3.5 h-3.5" />
                    Clear Saved Memories ({memories.length})
                  </button>
                </div>
              </div>

              <div className={`pt-4 border-t ${theme === "dark" ? "border-slate-800" : "border-slate-100"}`}>
                <h3 className={`text-sm font-bold mb-2 ${theme === "dark" ? "text-slate-200" : "text-slate-900"}`}>Privacy & Local Storage Engine</h3>
                <p className={`text-xs leading-relaxed mb-4 ${theme === "dark" ? "text-slate-300" : "text-slate-600"}`}>
                  Everything you speak with Shristi is securely managed. No API keys or conversation details are permanently stored on public cloud servers outside this container sandbox. All personalization values (user name, memories list, theme details) are saved locally on your device via standard browser <strong>localStorage</strong>.
                </p>
                <div className={`flex items-center justify-between p-3 border rounded-xl transition-colors duration-300 ${
                  theme === "dark" ? "bg-slate-950/60 border-slate-800" : "bg-amber-50/40 border-amber-100"
                }`}>
                  <div>
                    <span className={`text-xs font-bold block ${theme === "dark" ? "text-amber-400" : "text-amber-950"}`}>Local Data Health Check</span>
                    <span className="text-[10px] text-slate-500">Browser local quota and active storage slots check</span>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                    theme === "dark" ? "bg-amber-600 text-white" : "bg-amber-800 text-amber-50"
                  }`}>Good / Synced</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </main>

    </div>
  );
}
