export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface UserProfile {
  name: string;
  birthday: string;
  preferredLength: "Short" | "Medium" | "Long";
  humorPreference: "Gentle" | "Playful" | "Sarcastic";
  avatarUrl?: string;
}

export interface Memory {
  id: string;
  fact: string;
  category: "General" | "Favorites" | "Goals & Hobbies" | "Life & Routine";
  createdAt: string;
}

export type UserMood =
  | "Happy"
  | "Excited"
  | "Calm"
  | "Curious"
  | "Nervous"
  | "Lonely"
  | "Stressed"
  | "Confused"
  | "Angry"
  | "Sad"
  | "Motivated"
  | "Tired"
  | "Proud";
